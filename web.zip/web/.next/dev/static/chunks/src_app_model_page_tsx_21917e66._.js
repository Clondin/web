(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_fccd34db._.js",
  "static/chunks/node_modules_recharts_es6_bb75d22f._.js",
  "static/chunks/node_modules_951ca196._.js"
],
    source: "dynamic"
});
