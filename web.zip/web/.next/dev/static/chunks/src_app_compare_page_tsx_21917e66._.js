(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_e54e9f48._.js",
  "static/chunks/src_51e1b360._.js",
  "static/chunks/node_modules_pako_dist_pako_esm_mjs_367e3765._.js",
  "static/chunks/node_modules_jspdf_dist_jspdf_es_min_0d42d46a.js",
  "static/chunks/node_modules_recharts_es6_bb75d22f._.js",
  "static/chunks/node_modules_29802137._.js"
],
    source: "dynamic"
});
