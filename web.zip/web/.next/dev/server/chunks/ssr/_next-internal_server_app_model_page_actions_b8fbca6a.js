module.exports = [
"[project]/.next-internal/server/app/model/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_model_page_actions_b8fbca6a.js.map