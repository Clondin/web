module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/data/plans.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "get2025Plans",
    ()=>get2025Plans,
    "get2026Plans",
    ()=>get2026Plans,
    "getActivePlans",
    ()=>getActivePlans,
    "getPlanById",
    ()=>getPlanById,
    "getPlans",
    ()=>getPlans,
    "getPlansByYear",
    ()=>getPlansByYear,
    "healthPlans",
    ()=>healthPlans
]);
const healthPlans = [
    // ============ 2025 PLANS (Cigna Network) ============
    {
        id: '2025-buy-up',
        year: 2025,
        name: 'Buy-Up Plan',
        carrier: 'Cigna',
        network: 'Cigna Open Access Plus',
        networkType: 'Open Access Plus',
        premiums: {
            single: 171,
            couple: 360,
            employeeChild: 300,
            family: 525
        },
        deductible: {
            single: 1000,
            family: 2000
        },
        oopMax: {
            single: 5000,
            family: 10000
        },
        coinsurance: 20,
        copays: {
            pcp: 20,
            specialist: 40,
            urgentCare: 20,
            er: 100,
            imaging: 'deductible',
            labs: 'deductible'
        },
        copaysBeforeDeductible: true,
        rxTiers: {
            tier1: 15,
            tier2: 35,
            tier3: 75,
            deductible: 0
        },
        hsaEligible: false,
        description: 'Lower deductible plan with copays before deductible. Best for predictable healthcare needs with more comprehensive coverage.',
        highlights: [
            'Lowest deductible: $1,000 / $2,000',
            'Copays before deductible for PCP & Specialist',
            '80% / 20% coinsurance after deductible',
            '$0 Rx deductible',
            'OOP Max: $5,000 / $10,000'
        ],
        isActive: true
    },
    {
        id: '2025-value',
        year: 2025,
        name: 'Value Plan',
        carrier: 'Cigna',
        network: 'Cigna Open Access',
        networkType: 'Open Access',
        premiums: {
            single: 87,
            couple: 184,
            employeeChild: 153,
            family: 267
        },
        hasIncomeTiers: true,
        incomeTieredPremiums: {
            under200k: {
                single: 87,
                couple: 184,
                employeeChild: 153,
                family: 267
            },
            over200k: {
                single: 102,
                couple: 214,
                employeeChild: 178,
                family: 311
            }
        },
        deductible: {
            single: 1500,
            family: 3000
        },
        oopMax: {
            single: 6350,
            family: 12700
        },
        coinsurance: 30,
        copays: {
            pcp: 20,
            specialist: 40,
            urgentCare: 20,
            er: 100,
            imaging: 'deductible',
            labs: 'deductible'
        },
        copaysBeforeDeductible: true,
        rxTiers: {
            tier1: 15,
            tier2: 35,
            tier3: 75,
            deductible: 100
        },
        hsaEligible: false,
        description: 'Mid-tier plan with income-based premiums. Good balance between premium costs and coverage.',
        highlights: [
            'Income-based premiums (under/over $200k)',
            'Deductible: $1,500 / $3,000',
            'Copays before deductible for PCP & Specialist',
            '70% / 30% coinsurance',
            '$100 Rx deductible'
        ],
        isActive: true
    },
    {
        id: '2025-basic',
        year: 2025,
        name: 'Basic Plan (HRA)',
        carrier: 'Cigna',
        network: 'HRA Open Access',
        networkType: 'Open Access',
        premiums: {
            single: 40,
            couple: 119,
            employeeChild: 99,
            family: 173
        },
        deductible: {
            single: 2500,
            family: 5000
        },
        oopMax: {
            single: 6450,
            family: 12900
        },
        coinsurance: 30,
        copays: {
            pcp: 'deductible',
            specialist: 'deductible',
            urgentCare: 'deductible',
            er: 'deductible',
            imaging: 'deductible',
            labs: 'deductible'
        },
        copaysBeforeDeductible: false,
        rxTiers: {
            tier1: 25,
            tier2: 50,
            tier3: 75,
            deductible: 'medical'
        },
        hsaEligible: false,
        hraAmount: {
            single: 1000,
            family: 2000
        },
        description: 'Lowest premium option with employer HRA contribution. All services apply to deductible first.',
        highlights: [
            'Lowest weekly premiums',
            'HRA: $1,000 single / $2,000 dependents',
            'Deductible: $2,500 / $5,000',
            'All services subject to deductible',
            '70% / 30% coinsurance'
        ],
        isActive: true
    },
    // ============ 2026 PLANS (Oxford/UHC Network) ============
    {
        id: '2026-buy-up',
        year: 2026,
        name: 'Buy-Up Plan',
        carrier: 'Oxford',
        network: 'Oxford Freedom',
        networkType: 'Freedom (Widest)',
        premiums: {
            single: 171,
            couple: 360,
            employeeChild: 300,
            family: 525
        },
        deductible: {
            single: 1000,
            family: 2000
        },
        oopMax: {
            single: 4000,
            family: 8000
        },
        coinsurance: 10,
        copays: {
            pcp: 20,
            specialist: 40,
            urgentCare: 20,
            er: 100,
            imaging: 'deductible',
            labs: 'deductible'
        },
        copaysBeforeDeductible: true,
        rxTiers: {
            tier1: 25,
            tier2: 50,
            tier3: 75,
            deductible: 100
        },
        hsaEligible: false,
        description: 'Premium plan with Oxford Freedom network (widest access). Lower OOP max and better coinsurance than 2025.',
        highlights: [
            'Oxford Freedom network (widest access)',
            'Improved: 90% / 10% coinsurance',
            'Lower OOP Max: $4,000 / $8,000',
            'Deductible: $1,000 / $2,000',
            'Copays before deductible'
        ],
        isActive: true
    },
    {
        id: '2026-value',
        year: 2026,
        name: 'Value Plan',
        carrier: 'Oxford',
        network: 'Oxford Liberty',
        networkType: 'Liberty',
        premiums: {
            single: 87,
            couple: 184,
            employeeChild: 153,
            family: 267
        },
        hasIncomeTiers: true,
        incomeTieredPremiums: {
            under200k: {
                single: 87,
                couple: 184,
                employeeChild: 153,
                family: 267
            },
            over200k: {
                single: 102,
                couple: 214,
                employeeChild: 178,
                family: 311
            }
        },
        deductible: {
            single: 1500,
            family: 3000
        },
        oopMax: {
            single: 6350,
            family: 12700
        },
        coinsurance: 30,
        copays: {
            pcp: 20,
            specialist: 40,
            urgentCare: 20,
            er: 100,
            imaging: 'deductible',
            labs: 'deductible'
        },
        copaysBeforeDeductible: true,
        rxTiers: {
            tier1: 25,
            tier2: 50,
            tier3: 75,
            deductible: 100
        },
        hsaEligible: false,
        description: 'Mid-tier plan with Oxford Liberty network. Income-based premiums with good balance of cost and coverage.',
        highlights: [
            'Oxford Liberty network',
            'Income-based premiums (under/over $200k)',
            'Deductible: $1,500 / $3,000',
            'Copays before deductible',
            '70% / 30% coinsurance'
        ],
        isActive: true
    },
    {
        id: '2026-basic-a',
        year: 2026,
        name: 'Basic A – Liberty HSA',
        carrier: 'Oxford',
        network: 'Oxford Liberty',
        networkType: 'Liberty',
        premiums: {
            single: 69,
            couple: 144,
            employeeChild: 120,
            family: 209
        },
        deductible: {
            single: 2000,
            family: 4000
        },
        oopMax: {
            single: 5000,
            family: 10000
        },
        coinsurance: 30,
        copays: {
            pcp: 'deductible',
            specialist: 'deductible',
            urgentCare: 'deductible',
            er: 'deductible',
            imaging: 'deductible',
            labs: 'deductible'
        },
        copaysBeforeDeductible: false,
        rxTiers: {
            tier1: 25,
            tier2: 50,
            tier3: 75,
            deductible: 'medical'
        },
        hsaEligible: true,
        description: 'HSA-eligible high-deductible plan with Oxford Liberty network. Best for those who want tax-advantaged savings.',
        highlights: [
            'HSA Eligible – triple tax advantage',
            'Oxford Liberty network',
            'Deductible: $2,000 / $4,000',
            'Lower OOP Max: $5,000 / $10,000',
            '70% / 30% coinsurance'
        ],
        isActive: true
    },
    {
        id: '2026-basic-b',
        year: 2026,
        name: 'Basic B – Metro HSA + HRA',
        carrier: 'Oxford',
        network: 'Oxford Metro',
        networkType: 'Metro (Narrowest)',
        premiums: {
            single: 40,
            couple: 119,
            employeeChild: 99,
            family: 173
        },
        deductible: {
            single: 2500,
            family: 5000
        },
        oopMax: {
            single: 6450,
            family: 12900
        },
        coinsurance: 50,
        copays: {
            pcp: 40,
            specialist: 60,
            urgentCare: 40,
            er: 100,
            imaging: 'deductible',
            labs: 'deductible'
        },
        copaysBeforeDeductible: false,
        rxTiers: {
            tier1: 25,
            tier2: 50,
            tier3: 75,
            deductible: 'medical'
        },
        hsaEligible: true,
        hraAmount: {
            single: 1000,
            family: 2000
        },
        description: 'Lowest premium option with HSA eligibility and employer HRA. Metro network (excludes CVS) is the most limited.',
        highlights: [
            'Lowest weekly premiums',
            'HSA Eligible + HRA: $1,000 / $2,000',
            'Oxford Metro network (excludes CVS)',
            'Deductible: $2,500 / $5,000',
            '50% / 50% coinsurance'
        ],
        isActive: true
    }
];
const getPlans = ()=>healthPlans;
const getPlanById = (id)=>healthPlans.find((plan)=>plan.id === id);
const getPlansByYear = (year)=>healthPlans.filter((plan)=>plan.year === year);
const get2025Plans = ()=>getPlansByYear(2025);
const get2026Plans = ()=>getPlansByYear(2026);
const getActivePlans = ()=>healthPlans.filter((plan)=>plan.isActive);
}),
"[project]/src/lib/costCalculator.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateCosts",
    ()=>calculateCosts,
    "compareAllPlans",
    ()=>compareAllPlans,
    "defaultScenario",
    ()=>defaultScenario
]);
const SERVICE_COSTS = {
    pcpVisit: 200,
    specialistVisit: 350,
    labTest: 150,
    imagingTest: 500,
    erVisit: 2500,
    urgentCareVisit: 300
};
const RX_COSTS = {
    tier1: 30,
    tier2: 200,
    tier3: 500
};
function getDeductibleForEnrollment(plan, enrollmentType) {
    if (enrollmentType === 'single') {
        return plan.deductible.single;
    }
    return plan.deductible.family;
}
function getOopMaxForEnrollment(plan, enrollmentType) {
    if (enrollmentType === 'single') {
        return plan.oopMax.single;
    }
    return plan.oopMax.family;
}
function getPremiumForEnrollment(plan, scenario) {
    const { enrollmentType, incomeOver200k } = scenario;
    if (plan.hasIncomeTiers && plan.incomeTieredPremiums) {
        const tier = incomeOver200k ? plan.incomeTieredPremiums.over200k : plan.incomeTieredPremiums.under200k;
        return tier[enrollmentType];
    }
    return plan.premiums[enrollmentType];
}
function getHraForEnrollment(plan, enrollmentType) {
    if (!plan.hraAmount) return 0;
    if (enrollmentType === 'single') {
        return plan.hraAmount.single;
    }
    return plan.hraAmount.family;
}
function getCopayAmount(copay) {
    return copay === 'deductible' ? 0 : copay;
}
function isDeductibleCopay(copay) {
    return copay === 'deductible';
}
function calculateCosts(plan, scenario) {
    const deductible = getDeductibleForEnrollment(plan, scenario.enrollmentType);
    const oopMax = getOopMaxForEnrollment(plan, scenario.enrollmentType);
    const weeklyPremium = getPremiumForEnrollment(plan, scenario);
    const annualPremium = weeklyPremium * 52;
    const hraCredit = getHraForEnrollment(plan, scenario.enrollmentType);
    let runningDeductible = 0;
    let runningOop = 0;
    const applyCost = (serviceCost, copay, copaysBeforeDeductible = plan.copaysBeforeDeductible)=>{
        let patientCost = 0;
        const copayAmount = getCopayAmount(copay);
        const usesDeductible = isDeductibleCopay(copay);
        if (copaysBeforeDeductible && !usesDeductible) {
            patientCost = copayAmount;
        } else {
            if (runningDeductible < deductible) {
                const remainingDeductible = deductible - runningDeductible;
                const deductiblePortion = Math.min(serviceCost, remainingDeductible);
                patientCost = deductiblePortion;
                runningDeductible += deductiblePortion;
                if (serviceCost > deductiblePortion) {
                    const afterDeductible = serviceCost - deductiblePortion;
                    patientCost += afterDeductible * (plan.coinsurance / 100);
                }
            } else {
                patientCost = serviceCost * (plan.coinsurance / 100);
            }
        }
        if (runningOop + patientCost > oopMax) {
            patientCost = Math.max(0, oopMax - runningOop);
        }
        runningOop += patientCost;
        return patientCost;
    };
    const medicalCosts = {
        pcpCosts: 0,
        specialistCosts: 0,
        labCosts: 0,
        imagingCosts: 0,
        erCosts: 0,
        urgentCareCosts: 0,
        coinsuranceCosts: 0
    };
    for(let i = 0; i < scenario.pcpVisits; i++){
        medicalCosts.pcpCosts += applyCost(SERVICE_COSTS.pcpVisit, plan.copays.pcp);
    }
    for(let i = 0; i < scenario.specialistVisits; i++){
        medicalCosts.specialistCosts += applyCost(SERVICE_COSTS.specialistVisit, plan.copays.specialist);
    }
    for(let i = 0; i < scenario.labTests; i++){
        medicalCosts.labCosts += applyCost(SERVICE_COSTS.labTest, plan.copays.labs);
    }
    for(let i = 0; i < scenario.imagingTests; i++){
        medicalCosts.imagingCosts += applyCost(SERVICE_COSTS.imagingTest, plan.copays.imaging);
    }
    for(let i = 0; i < scenario.erVisits; i++){
        medicalCosts.erCosts += applyCost(SERVICE_COSTS.erVisit, plan.copays.er);
    }
    for(let i = 0; i < scenario.urgentCareVisits; i++){
        medicalCosts.urgentCareCosts += applyCost(SERVICE_COSTS.urgentCareVisit, plan.copays.urgentCare);
    }
    const rxCosts = {
        tier1Costs: 0,
        tier2Costs: 0,
        tier3Costs: 0,
        totalRxCosts: 0
    };
    const rxDeductibleApplies = plan.rxTiers.deductible === 'medical';
    const tier1Fills = scenario.tier1RxCount * 12;
    for(let i = 0; i < tier1Fills; i++){
        if (rxDeductibleApplies) {
            rxCosts.tier1Costs += applyCost(RX_COSTS.tier1, 'deductible');
        } else {
            rxCosts.tier1Costs += plan.rxTiers.tier1;
            runningOop += plan.rxTiers.tier1;
            if (runningOop > oopMax) {
                rxCosts.tier1Costs -= runningOop - oopMax;
                runningOop = oopMax;
            }
        }
    }
    const tier2Fills = scenario.tier2RxCount * 12;
    for(let i = 0; i < tier2Fills; i++){
        if (rxDeductibleApplies) {
            rxCosts.tier2Costs += applyCost(RX_COSTS.tier2, 'deductible');
        } else {
            rxCosts.tier2Costs += plan.rxTiers.tier2;
            runningOop += plan.rxTiers.tier2;
            if (runningOop > oopMax) {
                rxCosts.tier2Costs -= runningOop - oopMax;
                runningOop = oopMax;
            }
        }
    }
    const tier3Fills = scenario.tier3RxCount * 12;
    for(let i = 0; i < tier3Fills; i++){
        if (rxDeductibleApplies) {
            rxCosts.tier3Costs += applyCost(RX_COSTS.tier3, 'deductible');
        } else {
            rxCosts.tier3Costs += plan.rxTiers.tier3;
            runningOop += plan.rxTiers.tier3;
            if (runningOop > oopMax) {
                rxCosts.tier3Costs -= runningOop - oopMax;
                runningOop = oopMax;
            }
        }
    }
    rxCosts.totalRxCosts = rxCosts.tier1Costs + rxCosts.tier2Costs + rxCosts.tier3Costs;
    const totalMedicalCosts = medicalCosts.pcpCosts + medicalCosts.specialistCosts + medicalCosts.labCosts + medicalCosts.imagingCosts + medicalCosts.erCosts + medicalCosts.urgentCareCosts;
    const totalOutOfPocket = totalMedicalCosts + rxCosts.totalRxCosts;
    const hsaTaxSavings = plan.hsaEligible ? scenario.hsaContribution * (scenario.marginalTaxRate / 100) : 0;
    const totalTaxSavings = hsaTaxSavings;
    const totalAnnualCost = annualPremium + totalOutOfPocket;
    const netAnnualCost = totalAnnualCost - totalTaxSavings - hraCredit;
    return {
        planId: plan.id,
        planName: plan.name,
        year: plan.year,
        annualPremium,
        medicalCosts,
        rxCosts,
        totalMedicalCosts,
        totalRxCosts: rxCosts.totalRxCosts,
        totalOutOfPocket,
        deductibleMet: runningDeductible >= deductible,
        deductibleSpend: Math.min(runningDeductible, deductible),
        oopMaxMet: runningOop >= oopMax,
        oopMaxSpend: Math.min(runningOop, oopMax),
        hsaTaxSavings,
        totalTaxSavings,
        hraCredit,
        totalAnnualCost,
        netAnnualCost
    };
}
function compareAllPlans(plans, scenario) {
    const breakdowns = plans.map((plan)=>calculateCosts(plan, scenario));
    const sorted = [
        ...breakdowns
    ].sort((a, b)=>a.netAnnualCost - b.netAnnualCost);
    const lowestCostPlan = sorted[0];
    const highestCostPlan = sorted[sorted.length - 1];
    const potentialSavings = highestCostPlan.netAnnualCost - lowestCostPlan.netAnnualCost;
    return {
        breakdowns,
        lowestCostPlan,
        highestCostPlan,
        potentialSavings
    };
}
const defaultScenario = {
    enrollmentType: 'single',
    incomeOver200k: false,
    pcpVisits: 4,
    specialistVisits: 2,
    labTests: 4,
    imagingTests: 1,
    erVisits: 0,
    urgentCareVisits: 1,
    tier1RxCount: 1,
    tier2RxCount: 0,
    tier3RxCount: 0,
    hsaContribution: 0,
    marginalTaxRate: 22
};
}),
"[project]/src/lib/store.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAuthStore",
    ()=>useAuthStore,
    "usePlansStore",
    ()=>usePlansStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$plans$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/plans.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$costCalculator$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/costCalculator.ts [app-ssr] (ecmascript)");
;
;
;
;
const usePlansStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["persist"])((set, get)=>({
        plans: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$plans$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["healthPlans"],
        selectedPlanIds: [],
        scenario: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$costCalculator$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultScenario"],
        costBreakdowns: new Map(),
        setPlans: (plans)=>{
            set({
                plans
            });
            get().recalculateCosts();
        },
        addPlan: (plan)=>{
            set((state)=>({
                    plans: [
                        ...state.plans,
                        plan
                    ]
                }));
            get().recalculateCosts();
        },
        updatePlan: (id, updates)=>{
            set((state)=>({
                    plans: state.plans.map((p)=>p.id === id ? {
                            ...p,
                            ...updates
                        } : p)
                }));
            get().recalculateCosts();
        },
        deletePlan: (id)=>{
            set((state)=>({
                    plans: state.plans.filter((p)=>p.id !== id),
                    selectedPlanIds: state.selectedPlanIds.filter((pid)=>pid !== id)
                }));
            get().recalculateCosts();
        },
        selectPlan: (id)=>{
            set((state)=>{
                if (state.selectedPlanIds.includes(id)) return state;
                return {
                    selectedPlanIds: [
                        ...state.selectedPlanIds,
                        id
                    ]
                };
            });
        },
        deselectPlan: (id)=>{
            set((state)=>({
                    selectedPlanIds: state.selectedPlanIds.filter((pid)=>pid !== id)
                }));
        },
        clearSelectedPlans: ()=>{
            set({
                selectedPlanIds: []
            });
        },
        setSelectedPlans: (ids)=>{
            set({
                selectedPlanIds: ids
            });
        },
        setScenario: (updates)=>{
            set((state)=>({
                    scenario: {
                        ...state.scenario,
                        ...updates
                    }
                }));
            get().recalculateCosts();
        },
        resetScenario: ()=>{
            set({
                scenario: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$costCalculator$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultScenario"]
            });
            get().recalculateCosts();
        },
        recalculateCosts: ()=>{
            const { plans, scenario } = get();
            const breakdowns = new Map();
            for (const plan of plans){
                const breakdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$costCalculator$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["calculateCosts"])(plan, scenario);
                breakdowns.set(plan.id, breakdown);
            }
            set({
                costBreakdowns: breakdowns
            });
        }
    }), {
    name: 'health-plans-storage',
    partialize: (state)=>({
            scenario: state.scenario,
            selectedPlanIds: state.selectedPlanIds
        })
}));
const useAuthStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["persist"])((set)=>({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        login: async (email, password)=>{
            set({
                isLoading: true
            });
            // Simulate auth - in production, this would call an API
            await new Promise((resolve)=>setTimeout(resolve, 500));
            // Demo users
            if (email === 'admin@company.com' && password === 'admin123') {
                const user = {
                    id: '1',
                    email: 'admin@company.com',
                    name: 'Admin User',
                    role: 'admin',
                    createdAt: new Date()
                };
                set({
                    user,
                    isAuthenticated: true,
                    isLoading: false
                });
                return true;
            }
            if (email === 'user@company.com' && password === 'user123') {
                const user = {
                    id: '2',
                    email: 'user@company.com',
                    name: 'Demo User',
                    role: 'user',
                    createdAt: new Date()
                };
                set({
                    user,
                    isAuthenticated: true,
                    isLoading: false
                });
                return true;
            }
            set({
                isLoading: false
            });
            return false;
        },
        logout: ()=>{
            set({
                user: null,
                isAuthenticated: false
            });
        },
        setUser: (user)=>{
            set({
                user,
                isAuthenticated: !!user
            });
        }
    }), {
    name: 'auth-storage',
    partialize: (state)=>({
            user: state.user,
            isAuthenticated: state.isAuthenticated
        })
}));
// Initialize costs on first load
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
}),
"[project]/src/components/ui/Header.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/store.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Squares2X2Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Squares2X2Icon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/Squares2X2Icon.js [app-ssr] (ecmascript) <export default as Squares2X2Icon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$DocumentTextIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DocumentTextIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/DocumentTextIcon.js [app-ssr] (ecmascript) <export default as DocumentTextIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CalculatorIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CalculatorIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/CalculatorIcon.js [app-ssr] (ecmascript) <export default as CalculatorIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ScaleIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ScaleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ScaleIcon.js [app-ssr] (ecmascript) <export default as ScaleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$SparklesIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__SparklesIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/SparklesIcon.js [app-ssr] (ecmascript) <export default as SparklesIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Cog6ToothIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog6ToothIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/Cog6ToothIcon.js [app-ssr] (ecmascript) <export default as Cog6ToothIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowRightOnRectangleIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRightOnRectangleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ArrowRightOnRectangleIcon.js [app-ssr] (ecmascript) <export default as ArrowRightOnRectangleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$UserCircleIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UserCircleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/UserCircleIcon.js [app-ssr] (ecmascript) <export default as UserCircleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChevronDownIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ChevronDownIcon.js [app-ssr] (ecmascript) <export default as ChevronDownIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
const navigation = [
    {
        name: 'Dashboard',
        href: '/',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Squares2X2Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Squares2X2Icon$3e$__["Squares2X2Icon"]
    },
    {
        name: 'Plans',
        href: '/plans',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$DocumentTextIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DocumentTextIcon$3e$__["DocumentTextIcon"]
    },
    {
        name: 'Cost Modeler',
        href: '/model',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CalculatorIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CalculatorIcon$3e$__["CalculatorIcon"]
    },
    {
        name: 'Compare',
        href: '/compare',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ScaleIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ScaleIcon$3e$__["ScaleIcon"]
    },
    {
        name: "What's New",
        href: '/whats-new',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$SparklesIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__SparklesIcon$3e$__["SparklesIcon"]
    }
];
function Header() {
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const { user, isAuthenticated, logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAuthStore"])();
    const [showUserMenu, setShowUserMenu] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "bg-white border-b border-slate-200 sticky top-0 z-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-between items-center h-16",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/",
                                    className: "flex items-center gap-2.5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-9 h-9 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center shadow-sm",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-5 h-5 text-white",
                                                fill: "none",
                                                viewBox: "0 0 24 24",
                                                stroke: "currentColor",
                                                strokeWidth: 2,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    d: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ui/Header.tsx",
                                                    lineNumber: 40,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ui/Header.tsx",
                                                lineNumber: 39,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ui/Header.tsx",
                                            lineNumber: 38,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "hidden sm:block",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-lg font-bold text-slate-900",
                                                    children: "Benefits"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ui/Header.tsx",
                                                    lineNumber: 44,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-lg font-bold text-blue-600",
                                                    children: "Compare"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ui/Header.tsx",
                                                    lineNumber: 45,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/ui/Header.tsx",
                                            lineNumber: 43,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/ui/Header.tsx",
                                    lineNumber: 37,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                    className: "hidden lg:flex items-center gap-1",
                                    children: navigation.map((item)=>{
                                        const isActive = pathname === item.href || item.href !== '/' && pathname.startsWith(item.href);
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: item.href,
                                            className: `flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${isActive ? 'bg-blue-50 text-blue-700' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(item.icon, {
                                                    className: "h-4.5 w-4.5"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ui/Header.tsx",
                                                    lineNumber: 63,
                                                    columnNumber: 21
                                                }, this),
                                                item.name
                                            ]
                                        }, item.name, true, {
                                            fileName: "[project]/src/components/ui/Header.tsx",
                                            lineNumber: 54,
                                            columnNumber: 19
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/Header.tsx",
                                    lineNumber: 49,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ui/Header.tsx",
                            lineNumber: 36,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3",
                            children: isAuthenticated && user ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setShowUserMenu(!showUserMenu),
                                        className: "flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "w-7 h-7 bg-gradient-to-br from-slate-100 to-slate-200 rounded-full flex items-center justify-center",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$UserCircleIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UserCircleIcon$3e$__["UserCircleIcon"], {
                                                    className: "h-5 w-5 text-slate-500"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ui/Header.tsx",
                                                    lineNumber: 79,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ui/Header.tsx",
                                                lineNumber: 78,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "hidden sm:block",
                                                children: user.name
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ui/Header.tsx",
                                                lineNumber: 81,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ChevronDownIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__["ChevronDownIcon"], {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ui/Header.tsx",
                                                lineNumber: 82,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ui/Header.tsx",
                                        lineNumber: 74,
                                        columnNumber: 17
                                    }, this),
                                    showUserMenu && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg border border-slate-200 py-1 animate-fade-in",
                                        children: [
                                            user.role === 'admin' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/admin",
                                                className: "flex items-center gap-2 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50",
                                                onClick: ()=>setShowUserMenu(false),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Cog6ToothIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog6ToothIcon$3e$__["Cog6ToothIcon"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/Header.tsx",
                                                        lineNumber: 93,
                                                        columnNumber: 25
                                                    }, this),
                                                    "Admin Settings"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ui/Header.tsx",
                                                lineNumber: 88,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>{
                                                    logout();
                                                    setShowUserMenu(false);
                                                },
                                                className: "flex items-center gap-2 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 w-full",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowRightOnRectangleIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRightOnRectangleIcon$3e$__["ArrowRightOnRectangleIcon"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ui/Header.tsx",
                                                        lineNumber: 104,
                                                        columnNumber: 23
                                                    }, this),
                                                    "Sign Out"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ui/Header.tsx",
                                                lineNumber: 97,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ui/Header.tsx",
                                        lineNumber: 86,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ui/Header.tsx",
                                lineNumber: 73,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "/auth/login",
                                className: "btn-primary text-sm",
                                children: "Sign In"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/Header.tsx",
                                lineNumber: 111,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/Header.tsx",
                            lineNumber: 71,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/Header.tsx",
                    lineNumber: 35,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ui/Header.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "lg:hidden border-t border-slate-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex overflow-x-auto px-4 py-2 gap-1",
                    children: navigation.map((item)=>{
                        const isActive = pathname === item.href || item.href !== '/' && pathname.startsWith(item.href);
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: item.href,
                            className: `flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap ${isActive ? 'bg-blue-50 text-blue-700' : 'text-slate-600 hover:bg-slate-50'}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(item.icon, {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/Header.tsx",
                                    lineNumber: 137,
                                    columnNumber: 17
                                }, this),
                                item.name
                            ]
                        }, item.name, true, {
                            fileName: "[project]/src/components/ui/Header.tsx",
                            lineNumber: 128,
                            columnNumber: 15
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/Header.tsx",
                    lineNumber: 123,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ui/Header.tsx",
                lineNumber: 122,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/Header.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__98bde144._.js.map