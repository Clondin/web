module.exports = [
"[project]/.next-internal/server/app/plans/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_plans_page_actions_cf848e47.js.map